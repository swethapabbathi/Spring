package com.cg.spring.core;

public class Manager {
	
	private int Deptno;
	private String PName;
	private int PCode;
	
	public int getDeptno() {
		return Deptno;
	}
	public void setDeptno(int deptno) {
		Deptno = deptno;
	}
	public String getPName() {
		return PName;
	}
	public void setPName(String pName) {
		PName = pName;
	}
	public int getPCode() {
		return PCode;
	}
	public void setPCode(int pCode) {
		PCode = pCode;
	}

	@Override
	public String toString() {
		return "Manager [Deptno=" + Deptno + ", PName=" + PName + ", PCode=" + PCode + "]";
	}
	public Manager(int deptno, String pName, int pCode) {
		super();
		Deptno = deptno;
		PName = pName;
		PCode = pCode;
	}
	
}
