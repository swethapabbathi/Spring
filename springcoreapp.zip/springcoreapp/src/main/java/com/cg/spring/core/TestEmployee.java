package com.cg.spring.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
	
		ApplicationContext ac =new ClassPathXmlApplicationContext("spring.xml");
		ConfigurableApplicationContext context=new  ClassPathXmlApplicationContext("spring.xml");
		Employee e1= ac.getBean(Employee.class);
		Employee e2= context.getBean(Employee.class);
	
		//Employee e1=(Employee)ac.getBean("emp");
		/*e1.setId(123);
		e1.setName("Karthik");
		e1.setSalary(1200);*/
		System.out.println(e1);
		System.out.println(e2);
		context.close();
		
	/*	Manager m1=ac.getBean(Manager.class);
		m1.setDeptno(101);
		m1.setPCode(10000);
		m1.setPName("Mahesh");
		System.out.println(m1);*/

	}

}
