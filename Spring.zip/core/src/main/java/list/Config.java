package list;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;


@Configuration
@ComponentScan(basePackages="list")
public class Config {
		@Bean
		@Scope(value="singleton")
		public Question get()
		{
			Question p= new Question();
			p.setId(1);
			//p.setName("swe");
			return p;
		}
		
		@Bean
		@Scope(value="singleton")
		public Answer get1()
		{
			Answer a=new Answer();
			a.setId(1);
			a.setName("swetha");
			a.setBy("java is a bean");
			return a;
		}
		@Bean
		//@Scope(value="singleton")
		public ss get2()
		{
			ss s=new ss("maha");
			return s;
		}
		

}
