package list;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
@ComponentScan(basePackages="list")
public class conf {
	 @Bean
	    public Engine engine() {
	        return new Engine(5,"v8");
	    }
	 
	    @Bean
	    public Transmission transmission() {
	        return new Transmission("sliding");
	    }
	    
	    @Bean 
	    public Car car()
	    {
	    	Car c=new Car();
	    	return c;
	    }
}

 