package com.cg.spring.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.mvc.beans.Employee;
import com.cg.spring.mvc.repository.IEmployeeRep;

@Component
public class EmployeeServiceImpl implements IEmployeeService{

	@Autowired
	IEmployeeRep repo;
	
	public List<Employee> getAllEmp() {
		
		return repo.getAllEmp();
	}

	public void addEmp(Employee e) {
		repo.addEmp(e);
		
	}

	public Employee searchById(int id) {
		
		return repo.searchById(id);
	}

	public void deleteEmp(int id) {
		repo.deleteEmp(id);
		
	}
	public void update(int id,String name,double salary) {
		repo.update( id,name, salary);
	}

}
