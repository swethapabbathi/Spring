package com.cg.spring.mvc.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.mvc.beans.Employee;

@Repository
public interface IEmployeeRep {
	
	List<Employee> getAllEmp();
	void addEmp(Employee e);
	Employee searchById(int id);
	
	void deleteEmp(int id);
	void update(int id,String name,double salary);

}
