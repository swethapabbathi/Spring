package com.cg.spring.javaconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
@ComponentScan(basePackages="com.cg.spring.javaconfig")
public class ProductConfiguration {
		
	/*@Bean
		public Product getProduct()
		{
			Product p= new Product("iphone",44999.00);
			return p;
		}*/
	@Bean
	@Scope(value="singleton")
	//@Autowired
	public Product getProduct()
	{
		Product p= new Product("iphone");
		//p.setProductname("swe");
		p.setProductprice(1001);
		return p;
	}
}
