package com.cg.spring.core.beans;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Customer {
	private String firstname;
	private String lastname;
	/*private Address addr;*/
	/*private List <Address> addr;*/
	/*private Set <Address> addr;*/
	private Map<Integer,Address> addr;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	@Override
	public String toString() {
		return "Customer [firstname=" + firstname + ", lastname=" + lastname + ", addr=" + addr + "]";
	}
	
	
	public Customer(String firstname, String lastname, Map<Integer, Address> addr) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.addr = addr;
	}
	public Map<Integer, Address> getAddr() {
		return addr;
	}
	public void setAddr(Map<Integer, Address> addr) {
		this.addr = addr;
	}
	public Customer() {}
	

}
