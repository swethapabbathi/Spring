package com.example.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.beans.Product;


@Repository
public interface IProductRepo {

  List<Product> getAllProducts();
  Product search(int id);
  void add(String name,double price);
  void update(int id,String name,double price);
  void delete(int id);
  
}
