package com.example.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import com.example.beans.Product;
@Component
public class ProductRepoImpl implements IProductRepo {
	
	List<Product> list =new ArrayList<Product>();
	

	public List<Product> getAllProducts() {
		return list;
	}

	public Product search(int id) {
		 
		for(Product e:list )
		{
			if(e.getId()==id)
			{
				return e;
			}
		}
		return null;
	}

	@Override
	public void delete(int id) {
		
		for(Product p:list)
		{
			if(p.getId()==id)
				list.remove(p);
		}
	}

	@Override
	public void add(String name, double price) {
		Product pd=new Product();
		pd.setId(list.size()+1);
		pd.setName(name);
		pd.setPrice(price);
		list.add(pd);
		
	}

	@Override
	public void update(int id, String name, double price) {
		
		
		for(Product e:list)
		{
				if(e.getId()==id) {
					e.setName(name);
					e.setPrice(price);
				}
		}
	    
	}

	

}
