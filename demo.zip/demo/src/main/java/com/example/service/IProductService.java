package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.beans.Product;



@Service
public interface IProductService {
	 List<Product> getAllProducts();
	Product search(int id);
	void delete(int id);
	 void add(String name,double price);
	 void update(int id, String name, double price);
}
