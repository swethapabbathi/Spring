package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.beans.Product;
import com.example.service.IProductService;

@RestController
public class HelloController {

	@Autowired
	IProductService service;
	
	@RequestMapping("/hello")
	public String sayHello() {
		return "Hai, Good Afternnon";
	}
	
	@RequestMapping("/getall")
	public List<Product> getAllProduct() {
		return service.getAllProducts();
	}
	@RequestMapping("search/{id}")
	public Product Search(@PathVariable("id") int id) {
		return service.search(id);
	}
	@RequestMapping("delete/{id}")
	public String Delete(@PathVariable("id") int id) {
		service.delete(id);
		return "deleted";
	}
	
	@RequestMapping("add/{name}/{price}")
	public String Add(@PathVariable("name") String name,@PathVariable("price") double price) {
		service.add(name,price);
		return "1 product has been succssfully added to the list";
	}
	@RequestMapping("update/{id}/{name}/{price}")
	public String Update(@PathVariable("id") int id,@PathVariable("name") String name,@PathVariable("price") double price) {
		
		service.update(id,name,price);
		return "1 product has been succssfully modified in the list";
	}
	
	
}
