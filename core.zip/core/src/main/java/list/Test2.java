package list;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test2 {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext(conf.class);
		Car p=(Car)context.getBean(Car.class);
	System.out.println(p);
	}

}
