package list;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Test {

	public static void main(String[] args) {
		
	//	ApplicationContext context=new ClassPathXmlApplicationContext(Config.class);
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext(Config.class);
		Question q1= (Question)context.getBean(Question.class);
		q1.displayInfo();
	}

}
