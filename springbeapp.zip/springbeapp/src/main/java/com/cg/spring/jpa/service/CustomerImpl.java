package com.cg.spring.jpa.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.jpa.bean.Customer;
import com.cg.spring.jpa.repository.ICustomerRepo;

@Component
public class CustomerImpl implements ICustomerService{

	@Autowired
	ICustomerRepo repo;
	
	
	@Override
	public List<Customer> getAll() {
		List<Customer> list =new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list;
	}


	@Override
	public void delete(int id) {
		
		repo.deleteById(id);
		
	}
	@Override
	public Customer search(int id) {
		
		return null;
	}

	@Override
	public void addCutomer(Customer c) {
		repo.save(c);
	
		
	}


	@Override
	public void update(Customer c) {
	
		/*List<Customer> l=getAll();
		for(Customer e:l)
		{
			if(e.getId()==c.getId())
			{
				e.setMailid(c.getMailid());
				e.setCity(c.getCity());
				repo.save(e);
			}
		}*/
		Optional<Customer> p=repo.findById(c.getId());
		if(p.isPresent())
		{
			Customer c1=p.get();
			c1.setMailid(c.getMailid());
			c1.setCity(c.getCity());
			repo.save(c1);
			
		}
		
	}


	
	
	
	

}
